const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api"

export interface LoginCredentials {
  email: string
  password: string
}

export interface RegisterData {
  name: string
  email: string
  password: string
}

export interface Professor {
  id: string
  name: string
  email: string
  phone: string
  department: string
  specialization: string
  active: boolean
  createdAt: string
  updatedAt: string
}

export interface Subject {
  id: string
  name: string
  code: string
  workload: number
  description?: string
  professorId: string
  professor?: Professor
  createdAt: string
  updatedAt: string
}

export interface Schedule {
  id: string
  dayOfWeek: string
  startTime: string
  endTime: string
  classroom: string
  subjectId: string
  subject?: Subject
  createdAt: string
  updatedAt: string
}

class ApiClient {
  private getAuthHeader() {
    const token = localStorage.getItem("token")
    return token ? { Authorization: `Bearer ${token}` } : {}
  }

  async login(credentials: LoginCredentials) {
    const response = await fetch(`${API_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(credentials),
    })
    if (!response.ok) throw new Error("Login failed")
    return response.json()
  }

  async register(data: RegisterData) {
    const response = await fetch(`${API_URL}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    if (!response.ok) throw new Error("Registration failed")
    return response.json()
  }

  async getMe() {
    const response = await fetch(`${API_URL}/auth/me`, {
      headers: this.getAuthHeader(),
    })
    if (!response.ok) throw new Error("Failed to get user")
    return response.json()
  }

  // Professors
  async getProfessors(): Promise<Professor[]> {
    const response = await fetch(`${API_URL}/professors`, {
      headers: this.getAuthHeader(),
    })
    if (!response.ok) throw new Error("Failed to fetch professors")
    return response.json()
  }

  async getProfessor(id: string): Promise<Professor> {
    const response = await fetch(`${API_URL}/professors/${id}`, {
      headers: this.getAuthHeader(),
    })
    if (!response.ok) throw new Error("Failed to fetch professor")
    return response.json()
  }

  async createProfessor(data: Omit<Professor, "id" | "createdAt" | "updatedAt">) {
    const response = await fetch(`${API_URL}/professors`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...this.getAuthHeader(),
      },
      body: JSON.stringify(data),
    })
    if (!response.ok) throw new Error("Failed to create professor")
    return response.json()
  }

  async updateProfessor(id: string, data: Partial<Professor>) {
    const response = await fetch(`${API_URL}/professors/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        ...this.getAuthHeader(),
      },
      body: JSON.stringify(data),
    })
    if (!response.ok) throw new Error("Failed to update professor")
    return response.json()
  }

  async deleteProfessor(id: string) {
    const response = await fetch(`${API_URL}/professors/${id}`, {
      method: "DELETE",
      headers: this.getAuthHeader(),
    })
    if (!response.ok) throw new Error("Failed to delete professor")
    return response.json()
  }

  // Subjects
  async getSubjects(): Promise<Subject[]> {
    const response = await fetch(`${API_URL}/subjects`, {
      headers: this.getAuthHeader(),
    })
    if (!response.ok) throw new Error("Failed to fetch subjects")
    return response.json()
  }

  async getSubject(id: string): Promise<Subject> {
    const response = await fetch(`${API_URL}/subjects/${id}`, {
      headers: this.getAuthHeader(),
    })
    if (!response.ok) throw new Error("Failed to fetch subject")
    return response.json()
  }

  async createSubject(data: Omit<Subject, "id" | "createdAt" | "updatedAt" | "professor">) {
    const response = await fetch(`${API_URL}/subjects`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...this.getAuthHeader(),
      },
      body: JSON.stringify(data),
    })
    if (!response.ok) throw new Error("Failed to create subject")
    return response.json()
  }

  async updateSubject(id: string, data: Partial<Subject>) {
    const response = await fetch(`${API_URL}/subjects/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        ...this.getAuthHeader(),
      },
      body: JSON.stringify(data),
    })
    if (!response.ok) throw new Error("Failed to update subject")
    return response.json()
  }

  async deleteSubject(id: string) {
    const response = await fetch(`${API_URL}/subjects/${id}`, {
      method: "DELETE",
      headers: this.getAuthHeader(),
    })
    if (!response.ok) throw new Error("Failed to delete subject")
    return response.json()
  }

  // Schedules
  async getSchedules(): Promise<Schedule[]> {
    const response = await fetch(`${API_URL}/schedules`, {
      headers: this.getAuthHeader(),
    })
    if (!response.ok) throw new Error("Failed to fetch schedules")
    return response.json()
  }

  async getSchedule(id: string): Promise<Schedule> {
    const response = await fetch(`${API_URL}/schedules/${id}`, {
      headers: this.getAuthHeader(),
    })
    if (!response.ok) throw new Error("Failed to fetch schedule")
    return response.json()
  }

  async createSchedule(data: Omit<Schedule, "id" | "createdAt" | "updatedAt" | "subject">) {
    const response = await fetch(`${API_URL}/schedules`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...this.getAuthHeader(),
      },
      body: JSON.stringify(data),
    })
    if (!response.ok) throw new Error("Failed to create schedule")
    return response.json()
  }

  async updateSchedule(id: string, data: Partial<Schedule>) {
    const response = await fetch(`${API_URL}/schedules/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        ...this.getAuthHeader(),
      },
      body: JSON.stringify(data),
    })
    if (!response.ok) throw new Error("Failed to update schedule")
    return response.json()
  }

  async deleteSchedule(id: string) {
    const response = await fetch(`${API_URL}/schedules/${id}`, {
      method: "DELETE",
      headers: this.getAuthHeader(),
    })
    if (!response.ok) throw new Error("Failed to delete schedule")
    return response.json()
  }
}

export const api = new ApiClient()
